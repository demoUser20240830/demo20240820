import boto3
import requests
import json
from contextlib import closing


#The following variables could be passed as parameters
s3 = boto3.client('s3')
stepfunctions = boto3.client('stepfunctions')
url = 'https://eforexcel.com/wp/wp-content/uploads/2020/09/2m-Sales-Records.zip'
headers = {'User-Agent': 'xx'}
filename = url.split('/')[-1]

def file_fetcher(event, s3, url, headers, filename):
    # Get the file
     with closing(requests.get(url, headers=headers, stream=True)) as response:
        print(response)
        # Ensure the response is successful
        #if response.status_code == 200:
            # Stream the file to S3 bucket
        #   s3.upload_fileobj(response.raw, Bucket='iata-demo', Key=f'landing/{filename}')
        #else:
            
        try:
            token = event.get('token', None)
            print(f'Task Token: {token}')  # Added print statement for the task token
            # Ensure the response is successful
            if token is not None and response.status_code == 200:
                 # Stream the file to S3 bucket
                s3.upload_fileobj(response.raw, Bucket='iata-demo', Key=f'landing/{filename}')
                task_output = f'Successfully downloaded {filename} files to S3'
                params = {
                    'taskToken': token,
                    'output': json.dumps({'result': task_output})
                }
    
                try:
                   notification = stepfunctions.send_task_success(**params)
                except Exception as e:
                    print(f'Error sending task success: {str(e)}')
                    raise
            else:
                print(f"Failed to download file: {response.status_code}")

        except Exception as e:
            print(f'Error: {str(e)}')
            raise
def lambda_handler(event, context):
  # Get the file
  return file_fetcher(event, s3, url, headers, filename)