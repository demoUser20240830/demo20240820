import boto3
import zipfile
import io
import json
import pandas as pd
import awswrangler as wr

s3 = boto3.client('s3')
stepfunctions = boto3.client('stepfunctions')

source_bucket = 'iata-demo'
target_bucket = 'iata-demo'
csv_target = 'uncompressed'
parquet_target = 'raw'
object_key = 'landing/2m-Sales-Records.zip'


def lambda_handler(event, context):
    
    # Download the ZIP file from S3
    response = s3.get_object(Bucket=source_bucket, Key=object_key)
    zip_data = response['Body'].read()

    # Create a temporary in-memory file to store the ZIP data
    in_memory_zip = zipfile.ZipFile(io.BytesIO(zip_data))

    # Extract the contents of the ZIP file to a temporary directory
    temp_dir = '/tmp'
    in_memory_zip.extractall(temp_dir)

    #Process the extracted files (e.g., upload them to S3)
    for extracted_file in in_memory_zip.namelist():
        extracted_path = f'{temp_dir}/{extracted_file}'
        # Upload the extracted file to S3
        s3.upload_file(extracted_path, Bucket=target_bucket , Key=f'{csv_target}/{extracted_file}')
    
    try:
        token = event.get('token', None)
        print(f'Task Token: {token}')  # Added print statement for the task token
        if token is not None:
            
            task_output = f'Successfully unzipped {object_key} and uploaded extracted files to S3'
            params = {
                'taskToken': token,
                'output': json.dumps({'result': task_output})
            }

            try:
                notification = stepfunctions.send_task_success(**params)
            except Exception as e:
                print(f'Error sending task success: {str(e)}')
                raise
        else:
            print('Token not found in the event body.')

    except Exception as e:
        print(f'Error: {str(e)}')
        raise
 