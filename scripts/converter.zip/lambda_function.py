import boto3
import pandas as pd
import json
import awswrangler as wr


#The following variables could be passed as parameters
s3 = boto3.client('s3')
glue = boto3.client('glue')
stepfunctions = boto3.client('stepfunctions')
#-------------------------#
source_bucket = 'iata-demo'
target_bucket = 'iata-demo'
csv_target = 'uncompressed'
extracted_file = '2m Sales Records.csv'
parquet_target = 'raw'
object_key = 'landing/2m-Sales-Records.zip'
partitions = ['Country'] 
#-----------------------------------------#
database_name='iata-demo-database'
table_name='sales_records'

def lambda_handler(event, context):
    
    try:
        token = event.get('token', None)
        print(f'Task Token: {token}')  # Added print statement for the task token
        if token is not None:
            
            df = pd.read_csv(f's3://{source_bucket}/{csv_target}/{extracted_file}')
    
            wr.s3.to_parquet(
        
                df=df,
                path=f's3://{target_bucket}/{parquet_target}/{extracted_file}'.replace('.csv', '.parquet'),
                compression = 'gzip',
                dataset=True,
                database=database_name,
                table='sales_records',
                partition_cols= partitions,
            )
            
            task_output = f'Successfully created parquet file for{extracted_file} and added to data catalog'
            params = {
                'taskToken': token,
                'output': json.dumps({'result': task_output})
            }

            try:
                notification = stepfunctions.send_task_success(**params)
            except Exception as e:
                print(f'Error sending task success: {str(e)}')
                raise
        else:
            print('Token not found in the event body.')
            raise
        
    except Exception as e:
        print(f'Error: {str(e)}')
        raise